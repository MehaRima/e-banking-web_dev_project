
<?php
include('config.php');
?>
   
     		<div>
                    <h2><B>Administrator Dashboard</B></h2>		
                    <div class="news_info"></div>
<p><b>This is administrator main page. Here administrator can control all customer information, employee records, bank account details, etc.</b></p>
                    <div class="cleaner"></div>
     		</div>
</div><!-- end of content -->
            
            
                    <h2>Admin Login</h2>
                
               <ul>
                <li><a href="dash_admin.php">Home</a></li>
                <li><a href="changepassword.php">Change Password</a></li>
                </ul>
</div>

        <center>
            <form id="form" name="form" method="post" action="admindashboard.php">
              <p>
                <label for="admin" class="leftal"><strong>Email</strong></label>
                <input name="admin" type="text" id="admin" size="40"  class="rightal"/>
              </p>
              <p class="cleaner_h50" id="password2">
                <label for="pass"  class="leftal"><strong>Password</strong></label>
                <input name="pass" type="password" id="pass" class="rightal" size="40" />
              </p>
             
              <p class="cleaner_h50">
                <input  name="admin" type="submit"   class="submit_btn float_r" id="admin" value="Click here to Login"  />
              </p>
            </form></center>
          </div>


          <p>&nbsp;</p>
          <div class="cleaner_h50"></div>
        </div><!-- end of content -->
                
		