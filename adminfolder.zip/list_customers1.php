<?php
include('config.php');

?>
<!DOCTYPE html>
<html>
<head>
  <title>List customers</title><center>

</head>
<body>

<h3>Welcome to the ADMIN PANEL</h3> </center></div>

<div id="sidebar">
  <ul>
    <a href="add.php"><li>Add data</li></a>
    <a href="delete.php"><li>Delete data</li></a>
    <a href="update.php"><li>Update data</li></a>
    <a href="search.php"><li>Search data</li></a>
    <a href="list_transactions.php"><li>View Transactions</li></a>
    <a href="list_customers.php"><li>View Customer Details</li></a>
    <a href="logout.php"><li>Logout</li></a>

  </ul>
 
</div>
<div id="data">
  <?php
$queryString = "SELECT * FROM user_accnt";
$execute = mysqli_query($conn,$queryString) or die(mysqli_error($conn));
//var_dump($execute);
if(mysqli_num_rows($execute) > 0)
{
  //echo "Details are already submitted";

  ?>
     <center>
      <table border="1" cellpadding="5">
        <thead>
        <tbody><tr>
 
                 <th>ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Mobile</th>
          <th>Gender</th>
          <th>Email</th>
          <th>Password</th>
          <th>Address</th>
          <th>Aadhar</th>
          <th>PAN</th>
          <th>Path</th>
          <th>Account No.</th>
          <th>Balance</th>
          <th>Status</th>
        </tr>
        <thead>
        <tbody><?php
        while($row = mysqli_fetch_array($execute)) { ?>
          <tr>
        <td><?php echo $row['id']; ?><br></td>
      <td><?php echo $row['fname']; ?><br></td>
     <td><?php echo $row['lname']; ?><br></td>
      <td><?php echo $row['mobile']; ?><br></td>
      <td><?php echo $row['gender']; ?><br></td>
      <td><?php echo $row['email']; ?><br></td>
      <td><?php echo $row['password']; ?><br></td>
      <td><?php echo $row['address']; ?><br></td>
      <td><?php echo $row['aadhar']; ?><br></td>
      <td><?php echo $row['pan']; ?><br></td>
      <td>  <?php echo $row['path']; ?><br></td>
      <td><?php echo $row['account_no']; ?><br></td>
      <td><?php echo $row['balance']; ?><br></td>
      <td><img src="image.jpg" alt="image" width="42" height="42"></td>

      <td><?php if($row['status']==0) {
        ?>
        <a href="list_customers.php?id=<?php echo $row['id']?>&status=1">Activate</a>

        <?php

      } else {
          ?>
        <a href="list_customers.php?id=<?php echo $row['id']?>&status=0">Deactivate</a>
        
        <?php
      }?><br></td></tr>
      <?php } ?>

   </center>
</div>
</tbody>
</thead>
</table>

<?php
  }
  else
  {
    echo "No data found";
    
  
  }
  if(isset($_GET['status']) and isset($_GET['id'])) {

    $status = $_GET['status'];

    $id = $_GET['id'];

    if($status==1) {
      $account_no = "A".rand(100000000,999999999);
      $balance = 5000;
    } else {
       $account_no = '';
        $balance = 0;
    }

    $update = mysqli_query($conn,"UPDATE user_accnt SET account_no ='$account_no' , balance = '$balance' , status = '$status' WHERE id = '$id'") or die(mysqli_error($conn));
    if($update) {
      ?>
      <script type="text/javascript">
        alert('Status updated');
        window.location.href = "list_customers.php";
      </script>
      <?php
    }


  }
  ?>
</body>
</html>






      
      
      
  


