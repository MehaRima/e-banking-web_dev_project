<?php
#connection code

$host= 'localhost';
$user= 'root';
$password= '';
$dbname= 'bank';
$conn= mysqli_connect($host,$user,$password,$dbname) or die(mysqli_error($conn));



?>