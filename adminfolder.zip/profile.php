<?php
include('config.php');
if(!isset($_SESSION['student'])){
	header('Location:login.php?loginagain');
	exit;
}
 ?>
 <html>
	<head>
		<title>Profile</title>
		<meta charset="utf-8" />
		
	</head>
	<body>

	
			<table border=1 cellpadding="1">
				<thead>
					<th>ID</th>
					<th>Name</th>
					<th>Mobile</th>
					

				</thead>
			
			<td><?php echo $_SESSION['student']['id']; ?><br></td>
			<td><?php echo $_SESSION['student']['name']; ?><br></td>
			<td><?php echo $_SESSION['student']['mobile']; ?><br></td>
			</table><br>
			<a href="home.php">Click here to back to home page</a><br>
			<a href="update.php">Click here to update details</a>

			
			
</body>
</html>
