<?php
session_start();
include "class.acc.php";
include "class.cust.php";
include('config.php');
?>
<?php
function deletecust($theid){
if(isset($this->dbcon)){
//delete information from cutomer table and accounts table
$sql= "DELETE FROM customer WHERE cusid='".$theid."'";
if(!mysql_query($sql)){
         throw new Exception("Could not delete customer information cause:".mysql_error());
       }else{
           return TRUE;
           }
//now delete account of customer
$sql_acc= "DELETE FROM accounts WHERE cusid='".$theid."'";
if(!mysql_query($sql_acc)){
         throw new Exception("Could not delete account information cause:".mysql_error());
       }else{
           return TRUE;
           }
}
}?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>