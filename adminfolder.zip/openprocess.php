<?php

if($_SERVER['REQUEST_METHOD']==="POST")
{
	include('config.php');
	#store all values from form input in local variable
	$fname = mysqli_real_escape_string( $conn,trim($_POST['fname']));
	$lname = mysqli_real_escape_string( $conn,trim($_POST['lname']));
	$email = mysqli_real_escape_string( $conn,trim($_POST['email']));
	$password = mysqli_real_escape_string( $conn,trim($_POST['password']));
	$mobile = mysqli_real_escape_string( $conn,trim($_POST['mobile']));
	$gender = mysqli_real_escape_string( $conn,trim($_POST['gender']));
	$address = mysqli_real_escape_string( $conn,trim($_POST['address']));
	$aadhar = mysqli_real_escape_string( $conn,trim($_POST['aadhar']));
	$pan = mysqli_real_escape_string( $conn,trim($_POST['pan']));
    $account_no = mysqli_real_escape_string( $conn,trim($_POST['account_no']));
	$balance = mysqli_real_escape_string( $conn,trim($_POST['balance']));
	$status = mysqli_real_escape_string( $conn,trim($_POST['status']));
	

	
	if(empty($fname) or empty($lname) or empty($email) or empty($mobile) or empty($password) or empty($gender) or empty($address) or empty($aadhar) or empty($pan) or empty($account_no) or empty($balance) or empty($status))
	{

?><script type="text/javascript">alert('Empty field found!!');
window.location.href = 'openprocess.php?error';
</script><?php
}
else { 
	$queryString = "SELECT * FROM user_accnt WHERE email='$email'";
	#execute the above query string
	$execute = mysqli_query($conn,$queryString) or die (mysqli_error($conn));
	if (mysqli_num_rows($execute) > 0)
	{
		echo "Details are already present";
		exit;
 }
	else{

	
	#fresh data insert into database table -> details
	$QryString = "INSERT INTO user_accnt (fname,lname,email,mobile,password,gender,address,aadhar,pan,account_no,balance,status) VALUES ('$fname','$lname','$email','$mobile','$password','$gender','$address','$aadhar','$pan','$account_no','$balance',''$status')";
	#execute the above query string
	$exec = mysqli_query($conn,$QryString) or die (mysqli_error($conn));

	//var_dump($exec);
	if($exec)
	{
	
		?><script type="text/javascript">alert('Registered sucessfully');
		window.location.href = 'openaccnt.php?sucess';
	</script>
	<?php
	}
}
}
}
?>
