<?php
session_start();
include('config.php');
header('Location:login.php?loggedout');
exit;
?>