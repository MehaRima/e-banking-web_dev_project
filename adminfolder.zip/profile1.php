<?php include ('config.php')?>
        <?php if(isset($_POST['ok'])){
	$name = $_POST['name'];
	$gender = $_POST['gender'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$password = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	$address = $_POST['address'];
	$aadhar = $_POST['aadhar'];
	$pan = $_POST['pan'];
	#condition
	if(is_numeric($name)){
		echo 'Invalid Name';
	}else{
		if(is_numeric($gender)){
			echo 'Invalid Gender';
	}else{
		if($password!=$cpassword ) {
			echo 'Invalid password';
		}else{
			if(!is_numeric($aadhar)){
				echo 'Your Aadhar is Invalid';	
			}else{
				# save all information 
				$name = mysqli_real_escape_string($con,trim($name));
				$gender = mysqli_real_escape_string($con,trim($gender));
				$email = mysqli_real_escape_string($con,trim($email));
				$mobile = mysqli_real_escape_string($con,trim($mobile));	
				$password = mysqli_real_escape_string($con,trim($password));
				$address = mysqli_real_escape_string($con,trim($address));
				$aadhar = mysqli_real_escape_string($con,trim($aadhar));
				
          				$pan = mysqli_real_escape_string($con,trim($pan));
				# file upload
				$filename = $_FILES['picture']['name'];
				$filesize = $_FILES['picture']['size'];
				$filetype = $_FILES['picture']['type'];
				$filetmp_name = $_FILES['picture']['tmp_name'];
			if($filetype=="image/jpg"||$filetype=="image/png"||$filetype=="image/jpeg"){
				if($filesize<4000000){
					# directory
					$dir = "images";
					if(!file_exists($dir)){
						mkdir($dir);	
					}
					# create destination path
$destinationpath = $dir.'/'.rand(0000,9999).'_'.$filename;
					# upload the file 
					$upload = move_uploaded_file($filetmp_name,$path) or die($_FILES['picture']['error']);
					}
					}else{
					die("Invalid image type");	
				}
				# prepare string
				$qry = "INSERT INTO open VALUES ('0','$name','$gender','$email','$mobile','$password','$address','$path','$aadhar','$pan','0','0','0')";
# execute the above query
				$exec = mysqli_query($con,$qry) or die ( mysqli_error($con) );
				var_dump($exec);
			            header("location:profile.php");
				}}}}}?>		 
	



