<?php

if($_SERVER['REQUEST_METHOD']==="POST")
{
	include('config.php');
	#store all values from form input in local variable
	$name = mysqli_real_escape_string( $conn,trim($_POST['name']));
	$email = mysqli_real_escape_string( $conn,trim($_POST['email']));
	$password = mysqli_real_escape_string( $conn,trim($_POST['password']));
	
	if(empty($name) or empty($email) or empty($password))
	{

?><script type="text/javascript">alert('Empty field found!!');
window.location.href = 'admindashboard.php?error';
</script><?php
}
else { 
	$queryString = "SELECT * FROM admin WHERE email='$email'";
	#execute the above query string
	$execute = mysqli_query($conn,$queryString) or die (mysqli_error($conn));
	if (mysqli_num_rows($execute) > 0)
	{
		echo "Details are already present";
		exit;
 }
	else{

	
	#fresh data insert into database table -> student_details
	$QryString = "INSERT INTO admin(name,email,phone,password) VALUES ('$name','$email','$phone','$password')";
	#execute the above query string
	$exec = mysqli_query($conn,$QryString) or die (mysqli_error($conn));

	//var_dump($exec);
	if($exec)
	{
	
		?><script type="text/javascript">alert('Registered sucessfully');
		window.location.href = 'index.php?sucess';
	</script>
	<?php
	}
}
}
}
?>
