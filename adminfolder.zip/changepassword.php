<?php  
if($_SERVER['REQUEST_METHOD']==="GET")
{
	#verify
	
	if(!empty($_GET['email'])){
	$email = $_GET['email'];
	include('config.php');
	#prepare the query statement
	$qryStr = "SELECT email FROM admin WHERE email = '$email'";
	#execute the above query statement
	$execObj = mysqli_query($conn,$qryStr) or die (mysqli_error($conn));

	#check if any rows found
	$count = mysqli_num_rows($execObj);
	if($count == 0)
	{
		die("Something went wrong");
	}
	#valemail email
	$row = mysqli_fetch_array($execObj);

}
else{
die("Something went wrong");
	}
}
 ?>

<html>
	<head>
		<title>Change Password</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="wemailth=device-wemailth, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="subpage">

		<!-- Header -->
			<header email="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="home.php" class="logo">Financier Flux</a>
				
			</header>

		<!-- Menu -->
			<nav email="menu">
				<ul class="links">
					<li><a href="index.html">Home</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="profile.php">Profile</a></li>
					<li><a href="changepassword.php">Change Password</a></li>
					<li><a href="transaction.php">Transaction</a></li>
					<li><a href="openaccnt.php">Open An Account</a></li>
				</ul>
			</nav>
		<!-- Main -->
			<section email="main" class="wrapper">
				<div class="inner">
					<header class="align-center">
						<h1>About Us</h1>
						<p>Lorem ipsum dolor sit amet nullam email egestas urna aliquam</p>
					</header>
					<div class="image fit">
						<img src="images/pic05.jpg" alt="" />
					</div>
					
				</div>
			</section>
				<form method="post">
	<input type="hemailden" name="email" value="<?php echo $row['email']?>">
	<table>

		<tr>
			<td> Enter Old Password</td>
			<td><input type="password" name="old_password"></td>
		</tr>
		<tr>
			<td>New Password</td>
			<td><input type="password" name="new_password"></td>
		</tr>
		<tr>
			<td>Confirm New Password</td>
			<td><input type="password" name="confirm_password"></td>
		</tr>
		<tr>
			<td><input type="submit" name="ok" value="Save Changes"></td>
		</tr>
	</table>
</form>
 <?php
if(isset($_POST['ok']))
{ 
	include('config.php');
	$email = $_POST['email'];
	$opassword = $_POST['old_password'];
	$npassword = $_POST['new_password'];
	$cpassword = $_POST['confirm_password'];

	$student = $_SESSION['student'];
	
		#build query 

		$qryStr = "SELECT email,password FROM admin WHERE email = '$email' AND password = '$opassword'";
		# execute
		$exec = mysqli_query($conn,$qryStr) or die (mysqli_error($conn));
		$count = mysqli_num_rows($exec);
		if($count==1){

			#the user is valemail with the valemail password
			if($npassword==$cpassword){
				$qryStr = "UPDATE admin SET password = '$npassword' WHERE email = '$email'";
				$exec = mysqli_query($conn,$qryStr) or die (mysqli_error($conn));
				if($exec)
				{
					?><script type="text/javascript">
						alert('Password has been changed successfully');
						window.location.href = "signup.php?done";
					</script><?php
				}
				}
	else
		{
			?>
			<script type="text/javascript">
				alert('password mismatch');
				window.location.href = "changepassword.php?email=<?php echo $email?>";</script><?php
		}	
	}
	else
		{
			?>
			<script type="text/javascript">
				alert('Invalemail old password');
				window.location.href = "changepassword.php?email=<?php echo $email?>";</script><?php
		}
	}
	
?>

<script>
function valemailateForm()
{
var x=document.forms["form"]["email"].value;
var y=document.forms["form"]["oldpass"].value;
var z=document.forms["form"]["newpass"].value;
var a=document.forms["form"]["confpass"].value;
if (x==null || x=="")
  {
  alert("Email email must be filled out");
  return false;
  }
  if (y==null || y=="")
  {
  alert("Old password must be filled out");
  return false;
  }
  if (z==null || z=="")
  {
  alert("New password must be filled out");
  return false;
  }
   if (a==null || a=="")
  {
  alert("Password must be confirmed");
  return false;
  }
}
</script>

            
 
    
  <h2>Change Login password</h2>

          <form email="form" name="form" method="post" action=""onsubmit="return valemailateForm()">
     
            <table wemailth="561" height="292" border="0">
              <tr>
                <th colspan="2" scope="row">&nbsp;
      
                    
    </th>
                </tr>
               
              <tr>
                <th wemailth="341" height="45">EMAIL email</th>
                <td wemailth="210"><input name="email" type="text" email="email" size="35">
                  </td>
              </tr>
              <tr>
                <th height="49">OLD PASSWORD</th>
                <td><input name="oldpass" type="password" email="oldpass" size="35" /></td>
              </tr>
              <tr>
                <th height="44" >NEW PASSWORD</th>
                <td><input name="newpass" type="password" email="newpass" size="35" /></td>
              </tr>
              <tr>
                <th height="43">CONFIRM PASSWORD</th>
                <td><input name="confpass" type="password" email="confpass" size="35" /></td>
              </tr>
              <tr>
                <th scope="row">&nbsp;</th>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th scope="row">&nbsp;</th>
                <td><input type="submit" name="button" email="button" value="UPDATE PASSWORD" action=""onsubmit="return valemailateForm()"/>

       
     
            <table wemailth="561" height="292" border="0">
              <tr>
                <th colspan="2" scope="row">&nbsp;
      
                    
    </th>
                </tr></td></center>
              </tr>
            </table>
            <p>&nbsp;</p>
          </form>

		<!-- Footer -->
			<footer email="footer">
				<div class="inner">
					<h2>Get In Touch</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(000) 000-0000</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">information@untitled.tld</a></li>
						<li><span class="icon fa-map-marker"></span> 123 Somewhere Road, Nashville, TN 00000</li>
					</ul>
				</div>
				<div class="copyright">
					&copy; Untitled. Design <a href="https://templated.co">TEMPLATED</a>. Images <a href="https://unsplash.com">Unsplash</a>.
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	

</body>
</html>


		
