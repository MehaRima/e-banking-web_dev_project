<!DOCTYPE html>
<html>
<head>
		<title>Open Account</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="subpage">
		<section id="main" class="wrapper">
				<div class="inner">
					<header class="align-center">
						<h1>Account Opening Form</h1>
						
					</header>
					
				</div>
			</section>
<h2>Register here</h2>
<form method="post" action="openprocess.php">
	<table>
		<tr>
			<td>First Name</td>
			<td><input type="text" name="fname"></td>
		</tr>
		<tr>
			<td>Last Name</td>
			<td><input type="text" name="lname"></td>
		</tr>
		<tr>
			<td>Gender</td>
			<td><Input type="text" name="gender"></td>
	
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="email" name="email"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="password"></td>
		</tr>
		
		<tr>
			<td>Mobile no.</td>
			<td><input type="text" name="mobile"></td>
		</tr>
		<tr>
			<td>Address</td>
			<td><input type="text" name="address"></td>
		</tr>
		<tr>
			<td>Aadhar No.</td>
			<td><input type="text" name="aadhar"></td>
		</tr>
		<tr>
			<td>Pan</td>
			<td><input type="text" name="pan"></td>
		</tr>
		<tr>
			<td>Path</td>
			<td><input type="text" name="path"></td>
		</tr>
		<tr>
			<td>Account No.</td>
			<td><input type="text" name="account_no"></td>
		</tr>
		<tr>
			<td>Balance</td>
			<td><input type="text" name="balance"></td>
		</tr>
		<tr>
			<td>Status</td>
			<td><input type="text" name="status"></td>
		</tr>
	
		<tr>
			
			<td><input type="submit" name="ok" value="Sign Up"></td>
		</tr>
	</table>
</form>
			</body>
</html>