 <?php
include 'config.php';
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
  <title>List transactions</title><center>
</head>
<body>
<h3>Welcome to the ADMIN PANEL</h3> </center></div>

<div t_id="sidebar">
  <ul>
    
    <a href="list_transactions.php"><li>View Transactions</li></a>
    <a href="list_customers.php"><li>View Customer Details</li></a>
    <a href="logout.php"><li>Logout</li></a>

  </ul>
</div>
 
    <div id="data">
      <?php
      $queryString = "SELECT * FROM transaction";
      $execute = mysqli_query($conn,$queryString) or die(mysqli_error($conn));
//var_dump($execute);
      if(mysqli_num_rows($execute) > 0)
{
  //echo "Details are already submitted";

  ?> <center>
      <table border="1" cellpadding="5">
        <thead>
        <tbody><tr>
          <th>Transaction ID</th>
          <th>FROM Account No.</th>
          <th>TO Account No.</th>
          <th>Transaction Date</th>
          <th>Amount</th>
          <th>Type</th>
        </tr>
        
          <?php
           while($row = mysqli_fetch_array($execute)) { 
  //echo "Details are already submitted";
?>
          <tr>
          <td><?php echo $row['t_id']; ?><br></td>
          <td><?php echo $row['acc_no_from']; ?><br></td>
          <td><?php echo $row['acc_no_to']; ?><br></td>
          <td><?php echo $row['t_date']; ?><br></td>
          <td><?php echo $row['amt']; ?><br></td>
      <td><?php 

if($row['type']==1) {
        ?>
        <a href="list_transactions.php?t_id=<?php echo $row['t_id']?>&type=0">Amount Credited</a>

        <?php

      } else {
          ?>
        <a href="list_transactions.php?t_id=<?php echo $row['t_id']?>&type=1">Amount Debited</a>
        
        <?php
      }?><br></td></tr>
      <?php } ?>

  

</tbody>
</thead>
</table>
</center>
</div>
<?php
  }
  else
  {
    echo "No data found";
    
  
  }
  if(isset($_GET['type']) and isset($_GET['t_id'])) {

    $type = $_GET['type'];

    $t_id = $_GET['t_id'];

    if($type==1) {
     
    $acc_no_from = "A".rand(100000000,999999999);
      $acc_no_to = "A".rand(100000000,999999999);
      $amt = 5000;
    } else {
            $acc_no_from = '' ;
      $acc_no_to = '';
        $amt = 0;
    }

    $update = mysqli_query($conn,"UPDATE transaction SET acc_no_from ='$acc_no_from' , acc_no_to ='$acc_no_to' , amt = '$amt' , type = '$type' , t_date='$t_date'  WHERE t_id = '$t_id'") or die(mysqli_error($conn));
    if($update) {
      ?>
      <script type="text/javascript">
        alert('type updated');
        window.location.href = "list_transactions.php";
      </script>
      <?php
    }


  }
  ?>
</body>
</html>
 
