<?php
include('config.php');
?>
<?php
include('update.php');
?>
<?php
if(empty($_POST['upname']) or empty($_POST['upmob']))
{
?>
<script type="text/javascript">
	alert("empty field found");
</script>
<?php
}
else
{
	$sql_query = "UPDATE details SET name='".$_POST['upname']."',mobile='".$_POST['upmob']."' WHERE id='".$_SESSION['student']['id']."'";
	if(mysqli_query($conn,$sql_query))
	{
		$getNewValue = mysqli_query($conn,"SELECT * FROM details WHERE email='".$_SESSION['student']['email']."'");
		$row = mysqli_fetch_array($getNewValue);
		$_SESSION['student'] = $row;
		header('Location:profile.php?updated');
	}
	else
	{
		echo "not updated";
	}
}
?>