
<html>
<head>
	
	<?php
	error_reporting(0);
	include 'config.php';
	$name=$_POST['student'];
	
	$sql="DELETE FROM user_accnt WHERE email='$email'";

	if ($_POST['submit']) {
		if (mysqli_query($conn,$sql)) {
			echo "Data Deleted successfully";
		}
			else{
				echo "Something is not right!!!";
			}
		}
	

?><title>Operations on this panel</title></head>
<body>

	<form action="delete.php" method="POST">
		
		EMAIL:	<input type="email" name="email">
		
		<input type="submit" name="submit" value="Send Info">


	</form>

</body>
</html>