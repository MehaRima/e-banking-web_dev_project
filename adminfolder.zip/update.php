<?php
include('config.php');

?>	
<!DOCTYPE html>
<html>
<head>
	<title>Update Profile</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
</head>
<body class="subpage">

		<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="profile.php" class="logo">Financier Flux</a>
				
			</header>

		<!-- Menu -->
			<nav id="menu">
				<ul class="links">
					<li><a href="index.html">Home</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="profile.php">Profile</a></li>
					<li><a href="changepassword.php">Change Password</a></li>
					<li><a href="transaction.php">Transaction</a></li>
					<li><a href="openaccnt.php">Open An Account</a></li>
				</ul>
			</nav>
		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="inner">
					<header class="align-center">
						<h1>PROFILE</h1>
						<p>Lorem ipsum dolor sit amet nullam id egestas urna aliquam</p>
					</header>
					
				</div>
			</section>
	<h1 style="text-align: center;">UPDATE DETAILS</h1>
	<?php
	mysqli_select_db($conn,"netbanking");
	$sql = "SELECT * FROM details";
	$records = mysqli_query($conn,$sql);
	?>

	<form style="margin-left: 30%;" method="post" action="uprocess.php">
	<label>Name</label>
	<input type="text" name="upname" value="<?php echo $_SESSION['student']['name']?>"><br>
	<label>Mobile</label>
	<input type="text" name="upmob" value="<?php echo $_SESSION['student']['mobile']?>"><br>
	<input type="submit" name="ok" value="Update Details"><br>
	</form>
	CLICK <a href="home.php">Here</a> Back to home page


<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<h2>Get In Touch</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(000) 000-0000</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">information@untitled.tld</a></li>
						<li><span class="icon fa-map-marker"></span> 123 Somewhere Road, Nashville, TN 00000</li>
					</ul>
				</div>
				<div class="copyright">
					&copy; Untitled. Design <a href="https://templated.co">TEMPLATED</a>. Images <a href="https://unsplash.com">Unsplash</a>.
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	
</body>
</html>