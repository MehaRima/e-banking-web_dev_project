<!DOCTYPE html>
<html>
<head>
	
	<?php
	error_reporting(0);
	include 'config.php';
	$name=$_POST['user'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$sql="INSERT INTO admin (name,email,password) VALUES ('$name','$email','$password')";

	if ($_POST['submit']) {
		if (mysqli_query($conn,$sql)) {
			echo "Data Added successfully";
		}
			else{
				echo "Something is not right!!!";
			}
		}
	

?><title>Operations on this panel</title></head>
<body>

	<form action="add.php" method="POST">
		NAME:<input type="text" name="user">
		EMAIL:<input type="email" name="email">
		PASSWORD:<input type="password" name="password">
		<input type="submit" name="submit" value="Send Info">


	</form>

</body>
</html>