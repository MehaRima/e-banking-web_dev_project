<!DOCTYPE php>
<php>
<head>
	<title>Admin Panel</title>
<style>
	body{

		margin: 0px;
		border: 0px;
	}


	#header{

		width: 100px;
		height:	120px;
		background-color:black;
		color:white	;
		
	}
	


	#sidebar{


float: left;
		width: 300px	;
		height:	600px;
		background:	pink;
		
	}
	#logo{

		background: white;
		border-radius: 10px;
		height:150px;	
		width: 150px;}


	#data{

		height:	700px;
		background:lightblue;
		
	}
	ul li{
		padding: 20px;
		border-bottom: 2px solid grey;
	}
ul li:hover{

background: red;
color: white;

}
</style>


</head>
<body>



<div id=header"><center><img src="cc.png" id="logo"><br>
<h3>Welcome to the ADMIN PANEL</h3>	</center>


</div>
<div id="sidebar">
	<ul>
		<a href="add.php"><li>Add data</li></a>
		<a href="delete.php"><li>Delete data</li></a>
		<a href="update.php"><li>Update data</li></a>
		<a href="search.php"><li>Search data</li></a>
		<a href="list_transactions.php"><li>View Transactions</li></a>
		<a href="list_customers.php"><li>View Customer Details</li></a>
	
		<a href="logout.php"><li>Logout</li></a>

	</ul>
	


</div>
<div id="data">
	<center>
		<hr><br>
		<h2>You can now perform the desired operation.</h2>

     
      
  
	</center>
	


</div>






</body>
</php>