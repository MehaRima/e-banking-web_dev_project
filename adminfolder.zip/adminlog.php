<!DOCTYPE HTML>
<!--
  Intensify by TEMPLATED
  templated.co @templatedco
  Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
  <head>
    <title>Login</title>
    <meta charset="utf-8" />
    
  </head>
  <body>
 <!-- Main -->
      <section id="main" class="wrapper">
        <div class="inner">
          <header class="align-center">
  <form method="post" action="lprocess.php">
    <table>
      <tr>
        <td>Email:</td>
        <td><input type="email" name="email" required></td>
      </tr>
      <tr>
        <td>Password:</td>
        <td><input type="password" name="password" required></td>
      </tr>
      <tr>
        <td><input type="submit" name="login" value="Login"></td>
      </tr>
    </table>
    <a href='logout.php'>Logout</a>
  </form>
          
        </div>
      </section>



  </body>
</html>

          