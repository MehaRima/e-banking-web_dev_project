<?php include('config.php');?>
	<?php
	$s='';
	$output = null;
if(isset($_POST['search']))
{
	$n = $_POST['n'];
	$query = mysqli_query($conn,"SELECT * FROM student_details WHERE name='$n' ");
	$count = mysqli_num_rows($query);
	if($count == "0")
	{
$output =  "No result found";
	}	
else
{
	while ($row = mysqli_fetch_array($query)) {
		$s .= $row['id'];
		$s .= $row['name'];
		$s .= $row['email'];
		$s .= $row['phone'];
		$output = '<h3>'.$s.'</h3><br>';
		# code...
	}
 
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Search</title>
</head>
<body>
<form method="post" action="">
<input type="text" name="n" placeholder="search">
<input type="submit" name="search" value="Search">
</form>
<?php echo $output; ?>
</body>
</html>