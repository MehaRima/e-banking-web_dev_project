<!DOCTYPE html>
<html>
<head>
		<title>Open Account</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="subpage">
		<section id="main" class="wrapper">
				<div class="inner">
					<header class="align-center">
						<h1>Account Opening Form</h1>
						
					</header>
					
				</div>
			</section>
<h2>Register here</h2>
<form method="post" action="openprocess.php" enctype="multipart/form-data">
	<table>
		<tr>
			<td>First Name</td>
			<td><input type="text" name="fname"></td>
		</tr>
		<tr>
			<td>Last Name</td>
			<td><input type="text" name="lname"></td>
		</tr>
		<tr>
			<td>Gender</td>
		<td><select>
			<option value="male">Male</option>
			<option value="female">Female</option>
			<option value="others">Others</option>
		</select>
	</td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="email" name="email"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="password"></td>
		</tr>
		
		<tr>
			<td>Mobile no.</td>
			<td><input type="text" name="mobile"></td>
		</tr>
		<tr>
			<td>Address</td>
			<td><input type="text" name="address"></td>
		</tr>
		<tr>
			<td>Aadhar No.</td>
			<td><input type="text" name="aadhar"></td>
		</tr>
		<tr>
			<td>Path</td>
			<td><input type="file" name="picture">
				<input type="submit" name="upload" value="Upload"></td>
		</tr>
		<tr>
			<td>Pan</td>
			<td><input type="text" name="pan"></td>
		</tr>
		<tr>
			
			<td><input type="submit" name="ok" value="Sign Up"></td>
		</tr>
	</table>
</form>

<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="openaccnt.php" class="logo">Financier Flux</a>
				
			</header>

		<!-- Menu -->
			<nav id="menu">
				<ul class="links">
					<li><a href="index.html">Home</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="profile.php">Profile</a></li>
					<li><a href="changepassword.php">Change Password</a></li>
					<li><a href="transaction.php">Transaction</a></li>
					<li><a href="transfer.php">Transfer Money</a></li>
					<li><a href="openaccnt.php">Open An Account</a></li>
				</ul>
			</nav>

		<!-- Main -->
			
		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<h2>Get In Touch</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(000) 000-0000</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">information@untitled.tld</a></li>
						<li><span class="icon fa-map-marker"></span> 123 Somewhere Road, Nashville, TN 00000</li>
					</ul>
				</div>
				<div class="copyright">
					&copy; Untitled. Design <a href="https://templated.co">TEMPLATED</a>. Images <a href="https://unsplash.com">Unsplash</a>.
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			</body>
</html>