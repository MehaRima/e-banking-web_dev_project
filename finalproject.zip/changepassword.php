<?php  

	#verify
	include('config.php');
	if(!empty($_SESSION['student'])){
	$id = $_SESSION['student']['id'];
	
	#prepare the query statement
	$qryStr = "SELECT id FROM user_accnt WHERE id = '$id'";
	#execute the above query statement
	$execObj = mysqli_query($conn,$qryStr) or die (mysqli_error($conn));

	#check if any rows found
	$count = mysqli_num_rows($execObj);
	if($count == 0)
	{
		die("Something went wrong");
	}
	#valid id
	$row = mysqli_fetch_array($execObj);
}
else{
die("Something went wrong");
	}

 ?>

<html>
	<head>
		<title>Change Password</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="subpage">

		<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="home.php" class="logo">Financier Flux</a></header>

		<!-- Menu -->
			<nav id="menu">
				<ul class="links">
					<li><a href="index.html">Home</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="profile.php">Profile</a></li>
					<li><a href="changepassword.php">Change Password</a></li>
					<li><a href="transaction.php">Transaction</a></li>
					<li><a href="transfer.php">Transfer Money</a></li>
					<li><a href="openaccnt.php">Open An Account</a></li>
				</ul>
			</nav>
		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="inner">
					<header class="align-center">
						<h1>Change Password</h1>
						
					</header>
					</div>
			</section>
				<form method="post">
	<input type="hidden" name="id" value="<?php echo $row['id']?>">
	<table>

		<tr>
			<td> Enter Old Password</td>
			<td><input type="password" name="old_password"></td>
		</tr>
		<tr>
			<td>New Password</td>
			<td><input type="password" name="new_password"></td>
		</tr>
		<tr>
			<td>Confirm New Password</td>
			<td><input type="password" name="confirm_password"></td>
		</tr>
		<tr>
			<td><input type="submit" name="ok" value="Save Changes"></td>
		</tr>
	</table>
</form>
 <?php
if(isset($_POST['ok']))
{ 
	include('config.php');
	$id = $_POST['id'];
	$opassword = $_POST['old_password'];
	$npassword = $_POST['new_password'];
	$cpassword = $_POST['confirm_password'];

	//$id = $_SESSION['student'];
	
		#build query 

		$qryStr = "SELECT id,password FROM user_accnt WHERE id = '$id' AND password = '$opassword'";
		# execute
		$exec = mysqli_query($conn,$qryStr) or die (mysqli_error($conn));
		$count = mysqli_num_rows($exec);
		if($count==1){

			#the user is valid with the valid password
			if($npassword==$cpassword){
				$qryStr = "UPDATE user_accnt SET password = '$npassword' WHERE id = '$id'";
				$exec = mysqli_query($conn,$qryStr) or die (mysqli_error($conn));
				if($exec)
				{
					?><script type="text/javascript">
						alert('Password has been changed successfully');
						window.location.href = "signup.php?done";
					</script><?php
				}
				}
	else
		{
			?>
			<script type="text/javascript">
				alert('password mismatch');
				window.location.href = "changepassword.php?id=<?php echo $id?>";</script><?php
		}	
	}
	else
		{
			?>
			<script type="text/javascript">
				alert('Invalid old password');
				window.location.href = "changepassword.php?id=<?php echo $id?>";</script><?php

		}
}
?>

				<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<h2>Get In Touch</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(000) 000-0000</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">information@untitled.tld</a></li>
						<li><span class="icon fa-map-marker"></span> 123 Somewhere Road, Nashville, TN 00000</li>
					</ul>
				</div>
				<div class="copyright">
					&copy; Untitled. Design <a href="https://templated.co">TEMPLATED</a>. Images <a href="https://unsplash.com">Unsplash</a>.
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
</body>
</html>