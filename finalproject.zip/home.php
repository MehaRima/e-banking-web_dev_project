<!DOCTYPE HTML>
<!--
	Intensify by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>E-BANKING</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="index.html" class="logo">Financier Flux</a>
				<!-- <nav class="right"> -->
					<!-- <a href="#" class="button alt">Log in</a> -->
				<!-- </nav> -->
			</header>

		<!-- Menu -->
			<nav id="menu">
				<ul class="links">
					<li><a href="index.html">Home</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="profile.php">Profile</a></li>
					<li><a href="changepassword.php">Change Password</a></li>
					<li><a href="transaction.php">Transaction</a></li>
					<li><a href="transfer.php">Transfer Money</a></li>
					<li><a href="openaccnt.php">Open An Account</a></li>
					
				</ul>
			</nav>

		<!-- Banner -->
			<section id="banner">
				<div class="content">
					<h1>Welcome To Financier Flux</h1>
					<h3>Safe,Secure and Convinient Banking.</h3>
						<p>Online banking that enables you to have easy and safe access to your bank account</p>
					<ul class="actions">
						<li><a href="#one" class="button scrolly">Get Started</a></li>
					</ul>
				</div>
			</section>

		<!-- One -->
			<section id="one" class="wrapper">
				<div class="inner flex flex-3">
					<div class="flex-item left">
						<div>
							<h3>Safe And Secured</h3>
							<p>The security of your account is our priority<br>so,use e-banking to minimize the risk of fraud.</p>
						</div>
						<div>
							<h3>Save Time</h3>
							<p>Using the e-banking can also save the time someone would normally <br /> spend physically going to a bank and standing in a queue.</p>
						</div>
					</div>
					<div class="flex-item image fit round">
						<img src="images/image.png" alt="" />
					</div>
					<div class="flex-item right">
						<div>
							<h3>Tansfer Money</h3>
							<p>Experience secure and smooth online fund transfer through financier flux,<br />anywhere and at anytime.</p>
						</div>
						<div>
							<h3>Pay Bills</h3>
							<p>Using financier flux you can 'see and pay' your various bills online, directly from your financier flux account. <br /> </p>
						</div>
					</div>
				</div>
			</section>

		<!-- Two -->
			<section id="two" class="wrapper style1 special">
				<div class="inner">
					<h2>What Makes Financier Flux Unique???</h2>
					<figure>
					    <blockquote>
					         "Financier Flux is one of the 14 major banks which were nationalized on July 19, 1969. Its predecessor the Financier Flux Ltd., was formed in 1950 with the amalgamation of four banks viz. Comilla Banking Corporation Ltd. (1914), Bengal Central Bank Ltd. (1918), Comilla Union Bank Ltd."
					    </blockquote>
					   	</figure>
				</div>
			</section>

		<!-- Three -->
		<h1 align="center">Our Team</h1>
			<section id="three" class="wrapper">
				<div class="inner flex flex-3">
					<div class="flex-item box">
						<div class="image fit">
							<img src="images/pass2.jpg" alt="" />
						</div>
						<div class="content">
							<h3>KASEY</h3>
							<p>E-banking Cash Management Relationship Specialist</p>
						</div>
					</div>
					<div class="flex-item box">
						<div class="image fit">
							<img src="images/pass1.jpg" alt="">
						</div>
						<div class="content">
							<h3>Ashley</h3>
							<p>E-banking Team 
							Leader</p>
						</div>
					</div>
					<div class="flex-item box">
						<div class="image fit">
							<img src="images/pass3.jpg" alt="" />
						</div>
						<div class="content">
							<h3>Edwin</h3>
							<p>E-banking Support 
							Specialist</p>
						</div>
					</div>
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<h2>Get In Touch</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(000) 000-0000</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">information@untitled.tld</a></li>
						<li><span class="icon fa-map-marker"></span> 123 Somewhere Road, Nashville, TN 00000</li>
					</ul>
				</div>
				<div class="copyright">
					&copy; Untitled. Design <a href="https://templated.co">TEMPLATED</a>. Images <a href="https://unsplash.com">Unsplash</a>.
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>