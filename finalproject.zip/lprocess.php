<?php
if($_SERVER['REQUEST_METHOD']==="POST")
{
	include ('config.php');
	if(empty($_POST['email']) || empty($_POST['password']))
	{
		die("Something went wrong");
	}
	#sanitize data

	$email = mysqli_real_escape_string($conn,$_POST['email']); 
	$password = mysqli_real_escape_string($conn,$_POST['password']); 

	#verifying
	$qryStr = "SELECT * FROM user_accnt WHERE email = '$email' AND password = '$password'";

	#execute
	$execute = mysqli_query($conn,$qryStr) or die(mysqli_error($conn));
	#if any rows found
	$count = mysqli_num_rows($execute);
	if($count==0)
	{
		?><script type="text/javascript"> alert('Invalid user!!');
		window.location.href = "login.php?invalid";
	</script><?php
	}
	else
	{
		#a valid user
		$row = mysqli_fetch_array($execute);
		$_SESSION['student'] = $row;

		header('Location:home.php?success');
		exit;
	}
}
?>