<?php
include('config.php');
if(!isset($_SESSION['student'])){
	header('Location:login.php?loginagain');
	exit;
}
 ?>
 <html>
	<head>
		<title>Profile</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="subpage">

		<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="profile.php" class="logo">Financier Flux</a>
				
			</header>

		<!-- Menu -->
			<nav id="menu">
				<ul class="links">
					<li><a href="index.html">Home</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="profile.php">Profile</a></li>
					<li><a href="changepassword.php">Change Password</a></li>
					<li><a href="transaction.php">Transaction</a></li>
					<li><a href="transfer.php">Transfer Money</a></li>
					<li><a href="openaccnt.php">Open An Account</a></li>
				</ul>
			</nav>
		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="inner">
					<header class="align-center">
						<h1>PROFILE</h1>
						<p>Here are your details!!</p>
					</header>
					
				</div>
			</section>
			<table border=1 cellpadding="1">
				<tr>
					<th>ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Mobile</th>
          <th>Gender</th>
          <th>Address</th>
          <th>Aadhar</th>
          <th>PAN</th>
      </tr>
          
				<tr>	
			<td><?php echo $_SESSION['student']['id']; ?><br></td>

			<td><?php echo $_SESSION['student']['fname']; ?><br></td>
			<td><?php echo $_SESSION['student']['lname']; ?><br></td>
			<td><?php echo $_SESSION['student']['mobile']; ?><br></td>
			<td><?php echo $_SESSION['student']['gender']; ?><br></td>
			<td><?php echo $_SESSION['student']['address']; ?><br></td>
			<td><?php echo $_SESSION['student']['aadhar']; ?><br></td>
			<td><?php echo $_SESSION['student']['pan']; ?><br></td>
		</tr>
			
			</table><br><br>
			<a href="home.php">Click here to back to home page</a><br>
			<a href="update.php">Click here to update details</a>

			<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<h2>Get In Touch</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(000) 000-0000</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">information@untitled.tld</a></li>
						<li><span class="icon fa-map-marker"></span> 123 Somewhere Road, Nashville, TN 00000</li>
					</ul>
				</div>
				<div class="copyright">
					&copy; Untitled. Design <a href="https://templated.co">TEMPLATED</a>. Images <a href="https://unsplash.com">Unsplash</a>.
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			
</body>
</html>
