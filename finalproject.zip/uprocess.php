<?php
include('config.php');
?>

<?php
if(empty($_POST['upfname']) or empty($_POST['uplname'])or empty($_POST['upmob']) or empty($_POST['upgender']) or empty($_POST['upaddress']) or empty($_POST['upaadhar']) or empty($_POST['uppan']) or empty($_POST['upemail']))
{
?>
<script type="text/javascript">
	alert("empty field found");
</script>
<?php
}
else
{
	$sql_query = "UPDATE user_accnt SET fname='".$_POST['upfname']."',lname='".$_POST['uplname']."',mobile='".$_POST['upmob']."',gender='".$_POST['upgender']."',address='".$_POST['upaddress']."',aadhar='".$_POST['upaadhar']."',pan='".$_POST['uppan']."'  WHERE id='".$_SESSION['student']['id']."'";
	if(mysqli_query($conn,$sql_query))
	{
		$getNewValue = mysqli_query($conn,"SELECT * FROM user_accnt WHERE email='".$_SESSION['student']['email']."'");
		$row = mysqli_fetch_array($getNewValue);
		$_SESSION['student'] = $row;
		header('Location:profile.php?updated');
	}
	else
	{
		echo "not updated";
	}
}
?>