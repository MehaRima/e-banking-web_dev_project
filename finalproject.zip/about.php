<!DOCTYPE HTML>
<!--
	Intensify by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>About Us</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="subpage">

		<!-- Header -->
			<header id="header">
				<nav class="left">
					<a href="#menu"><span>Menu</span></a>
				</nav>
				<a href="index.html" class="logo">Financier Flux</a>
				
			</header>

		<!-- Menu -->
			<nav id="menu">
				<ul class="links">
					<li><a href="index.html">Home</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="signup.php">Sign Up</a></li>
				</ul>
			</nav>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="inner">
					<header class="align-center">
						<h1>About Us</h1>
						<p></p>
					</header>
					<div class="image fit">
						<img src="images/Internet-Banking.jpg" alt="" />
					</div>
					<p>
						Traditional banks offer many services to their customers, including accepting customer money deposits, providing various banking services to customers, and making loans to individuals and companies. Compared with traditional channels of offering banking services through physical branches, e-banking uses the Internet to deliver traditional banking services to their customers, such as opening accounts, transferring funds, and electronic bill payment.
						</p>

					<p>
E-banking can be offered in two main ways. First, an existing bank with physical offices can also establish an online site and offer e-banking services to its customers in addition to the regular channel. For example, Citibank is a leader in e-banking, offering walk-in, face-to-face banking at its branches throughout many parts of the world as well as e-banking services through the World Wide Web. Citibank customers can access their bank accounts through the Internet, and in addition to the core e-banking services such as account balance inquiry, funds transfer, and electronic bill payment, Citibank also provides premium services including financial calculators, online stock quotes, brokerage services, and insurance.
					</p>.
					<p>
						Financier Flux played a significant role in the spread of banking services in different parts of the country, more particularly in Western and North-Eastern India. Financier Flux has sponsored 4 Regional Rural Banks (RRB) one each in West Bengal, Assam, Manipur and Tripura. These four RRBs together have over 1000 branches. Financier Flux has contributed 35% of the share capital/ additional capital to all the four RRBs in four different states. In its efforts to provide banking services to the people living in the not easily accessible areas of the Sunderbans in West Bengal, Financier Flux had established two floating mobile branches on motor launches which moved from island to island on different days of the week. The floating mobile branches were discontinued with the opening of full-fledged branches at the centers which were being served by the floating mobile branches. UBI is also known as the 'Tea Bank' because of its age-old association with the financing of tea gardens. It has been the largest lender to the tea industry.
					</p>


<p>
The Bank has three full fledged Overseas Branches one each at Kolkata, New Delhi and Mumbai with fully equipped dealing room and SWIFT terminal . Operations of all the branches have since been computerized and Electronic Fund Transfer System came to be implemented in the Bank's branches across the country. The Bank has ATMs all over the country.
					</p>
					
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<h2>Get In Touch</h2>
					<ul class="actions">
						<li><span class="icon fa-phone"></span> <a href="#">(000) 000-0000</a></li>
						<li><span class="icon fa-envelope"></span> <a href="#">information@untitled.tld</a></li>
						<li><span class="icon fa-map-marker"></span> 123 Somewhere Road, Nashville, TN 00000</li>
					</ul>
				</div>
				<div class="copyright">
					&copy; Untitled. Design <a href="https://templated.co">TEMPLATED</a>. Images <a href="https://unsplash.com">Unsplash</a>.
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>