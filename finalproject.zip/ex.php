 <?php 
 include ('config.php');
 
  if (isset($_GET['student'])) 
  {       
   $student = $_GET['student'];       
     $qryStr = "SELECT * FROM student_details WHERE name = '$name'"); 
 $execute = mysqli_query($conn,$qryStr) or die(mysqli_error($conn));
	#if any rows found
	$count = mysqli_num_rows($execute);
           if ($count == 1) 
           	{           
           	 

           	  }  
  }
 ?>

     <!DOCTYPE html>
             <html> 
                <head>     
                   <meta charset=”UTF-8″>       
                    <title><?php echo $row['name'] ?>
               Profile
           </title>   
            </head>  
              <body>     
                 <a href="profile.php">Profile</a> | <?php echo $row['name'] ?>      
                 <h3>Personal Information |       
                  <?php            $visitor = $_SESSION['name'];           
                   if ($student == $visitor ) 
                   	{ ?>           
                   	 <a href="edit-profile.php?user=<?php echo $row['name'] ?>">Edit Profile</a>           
                   	  <?php }        ?>       
                   	  </h3>       
                  <table>       
                       <tr>              
                         <td>Name:</td>              
                         <td><?php echo $row['full_name'] ?></td>     
                                </tr>           
                                 <tr>            
                                     <td>Age:</td>            

                                         <td><?php echo $row['age'] ?></td>         
                                            </tr>         
                                               <tr>       
                                                        <td>Gender:</td>               
                                                         <td><?php echo $row['gender'] ?></td>           
                                                          </tr>           
                                                           <tr>               
                                                            <td>Address:</td>         
                                <td><?php echo $row['address'] ?></td>      
                                      </tr>       
                                       </table>   
                                        </body>
                                        </html>